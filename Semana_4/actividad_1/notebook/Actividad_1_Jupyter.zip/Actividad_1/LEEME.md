# Actividad 1 — Regresión lineal

Abrí `Regresion_lineal_electricidad.ipynb` en Jupyter Notebook y mantené `demanda-de-electricidad-datos-mensuales.csv` en la misma carpeta.

El cuaderno contiene las explicaciones, la preparación de los datos, los gráficos, el entrenamiento, la evaluación y la interpretación. Para reproducirlo, reiniciá el kernel y ejecutá todas las celdas en orden. La lectura y limpieza ocurren en memoria: el CSV no se sobrescribe.

Se necesitan Python, pandas, numpy, matplotlib y scikit-learn. Si tu entorno de Jupyter indica que falta alguna biblioteca, podés instalarla desde una celda con:

```python
%pip install pandas numpy matplotlib scikit-learn
```

El objetivo es estimar la potencia máxima mensual (MW) con cuatro predictoras del mismo mes. No es un pronóstico anticipado. La separación 80/20 es cronológica.

La copia del CSV es idéntica al archivo aportado. El material está preparado localmente; no se publicó en GitHub ni se entregó en el campus.
